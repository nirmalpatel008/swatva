Swatva sample data
==================

Everything in this folder is made up. The names, phone numbers, Aadhaar-style
numbers and bank details were generated at random and belong to no one.

  college_erp.db           a fake college database: students, scholarships, staff, marks, courses
  admissions_2026.csv      an admissions office export
  hostel_allotment.csv     a hostel sheet with phone numbers typed into the Remarks column
  timetable_sem5.csv       no personal data, to show that Swatva stays quiet when it should
  student_list_sem3.xlsx   a student list the way offices keep it: title rows, numbers stored
                           as numbers, and a second sheet with Gujarati column names

To scan it:

  pip install git+https://github.com/nirmalpatel008/swatva.git openpyxl
  python -m swatva scan swatva-sample-data

Then open swatva-report/swatva-report.html in your browser.
More at https://swatva.org
